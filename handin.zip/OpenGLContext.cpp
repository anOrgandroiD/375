/// \file OpenGLContext.cpp
/// \brief Definitions of OpenGLContext member and associated global functions.
/// \author Chad Hogg
/// \version A02

#include "OpenGLContext.hpp"

OpenGLContext::~OpenGLContext ()
{
}
